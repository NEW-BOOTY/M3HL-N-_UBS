/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

# M3hl@n! Plugin API — Specification

A plugin is any executable that:
- Reads JSON from stdin
- Writes JSON to stdout
- Exits 0 on success

Lifecycle hooks:
- pre_build
- post_build
- pre_target
- post_target

Manifest example:
```yaml
plugins:
  - id: example
    path: plugins/example-plugin.sh
    enabled: true
    hooks: ["pre_build", "post_build"]
```

/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

