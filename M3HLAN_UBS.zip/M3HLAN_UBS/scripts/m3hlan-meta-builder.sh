#!/usr/bin/env bash
# Copyright © 2025 Devin B. Royal.
# All Rights Reserved.

set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LOG_DIR="${PROJECT_ROOT}/logs"
mkdir -p "${LOG_DIR}"

MAX_RETRIES=5
SLEEP_BASE=2

log() {
  local level="$1"; shift
  local msg="$*"
  local ts
  ts="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
  echo "[$ts] [$level] $msg" | tee -a "${LOG_DIR}/m3hlan-meta-builder.log"
}

run_module() {
  local module_name="$1"
  local script_path="$2"

  log INFO "Starting module: ${module_name} (${script_path})"
  local attempt=1

  while (( attempt <= MAX_RETRIES )); do
    if bash "${script_path}" >> "${LOG_DIR}/${module_name}.log" 2>&1; then
      log INFO "Module ${module_name} completed successfully on attempt ${attempt}"
      return 0
    else
      log WARN "Module ${module_name} failed on attempt ${attempt}"
      (( attempt++ )) || true
      if (( attempt > MAX_RETRIES )); then
        log ERROR "Module ${module_name} exhausted retries."
        echo "TRY AGAIN."
        return 1
      fi
      local sleep_for=$(( SLEEP_BASE * attempt ))
      log INFO "Retrying ${module_name} after ${sleep_for}s..."
      sleep "${sleep_for}"
    fi
  done
}

check_prereqs() {
  local missing=0
  for cmd in bash python3 javac cargo rustc; do
    if ! command -v "${cmd}" >/dev/null 2>&1; then
      log WARN "Missing dependency: ${cmd}"
      missing=1
    else
      log INFO "Found dependency: ${cmd} -> $(command -v "${cmd}")"
    fi
  done

  if (( missing )); then
    log WARN "Some dependencies are missing. The build scripts will still generate code, but compilation may fail until you install them."
  fi
}

main() {
  cd "${PROJECT_ROOT}"

  log INFO "M3hl@n! Unified Build System META-BUILDER starting..."
  check_prereqs

  run_module "core_engine_bundle"        "${PROJECT_ROOT}/scripts/bundle_core_engine.sh"
  run_module "manifest_adapter_bundle"   "${PROJECT_ROOT}/scripts/bundle_manifest_adapter.sh"
  run_module "observability_bundle"      "${PROJECT_ROOT}/scripts/bundle_observability.sh"
  run_module "dev_ergonomics_bundle"     "${PROJECT_ROOT}/scripts/bundle_dev_ergonomics.sh"
  run_module "extension_ecosystem_bundle" "${PROJECT_ROOT}/scripts/bundle_extension_ecosystem.sh"

  log INFO "All modules completed successfully."
  echo "GOT UM."
}

main "$@"

# Copyright © 2025 Devin B. Royal.
# All Rights Reserved.
