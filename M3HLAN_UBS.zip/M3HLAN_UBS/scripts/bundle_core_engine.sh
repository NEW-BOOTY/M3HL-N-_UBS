#!/usr/bin/env bash
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LOG="${ROOT}/logs/bundle_core_engine.log"
mkdir -p "${ROOT}/logs"

log() {
  local msg="$*"
  local ts
  ts="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
  echo "[${ts}] [CORE] ${msg}" | tee -a "${LOG}"
}

require_cmd() {
  local name="$1"
  if ! command -v "${name}" >/dev/null 2>&1; then
    log "ERROR Missing command: ${name}"
    return 1
  fi
  log "INFO Found ${name} at $(command -v "${name}")"
  return 0
}

ensure_deps() {
  local missing=0
  for c in python3 javac java cargo rustc; do
    if ! require_cmd "${c}"; then
      missing=1
    fi
  done
  if [[ "${missing}" -ne 0 ]]; then
    log "ERROR One or more required commands are missing."
    exit 1
  fi
}

generate_layout() {
  log "INFO Generating engine directory layout..."
  mkdir -p \
    "${ROOT}/engine/java/src/main/java/com/m3hlan/engine" \
    "${ROOT}/engine/java/src/main/resources" \
    "${ROOT}/engine/python" \
    "${ROOT}/engine/rust/src" \
    "${ROOT}/cas" \
    "${ROOT}/bin"
}

compile_java() {
  log "INFO Compiling Java engine..."
  mkdir -p "${ROOT}/engine/java/target"
  javac -d "${ROOT}/engine/java/target" \
    "${ROOT}/engine/java/src/main/java/com/m3hlan/engine/M3hlanEngine.java"
}

check_python() {
  log "INFO Verifying Python engine..."
  python3 -m py_compile "${ROOT}/engine/python/m3h_core.py"
}

build_rust() {
  log "INFO Building Rust CAS helper..."
  ( cd "${ROOT}/engine/rust" && cargo build --release )
}

write_launcher() {
  local launcher="${ROOT}/bin/m3hlan-build"
  cat > "${launcher}" <<'LAUNCH'
#!/usr/bin/env bash
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */

set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

usage() {
  cat <<USAGE
Usage: m3hlan-build <command>

Commands:
  java        Compile and run the Java engine.
  python-core Run the Python CAS engine.
  rust-cas    Run the Rust CAS helper.

Examples:
  echo "hello" | m3hlan-build java
  echo "hello" | m3hlan-build python-core
  echo "hello" | m3hlan-build rust-cas
USAGE
}

cmd="${1:-java}"

case "${cmd}" in
  java)
    mkdir -p "${ROOT}/engine/java/target"
    javac -d "${ROOT}/engine/java/target" \
      "${ROOT}/engine/java/src/main/java/com/m3hlan/engine/M3hlanEngine.java"
    java -cp "${ROOT}/engine/java/target" com.m3hlan.engine.M3hlanEngine
    ;;
  python-core)
    python3 "${ROOT}/engine/python/m3h_core.py"
    ;;
  rust-cas)
    cargo run --manifest-path "${ROOT}/engine/rust/Cargo.toml" --release
    ;;
  -*|--help|help)
    usage
    ;;
  *)
    echo "Unknown command: ${cmd}" >&2
    usage >&2
    exit 1
    ;;
esac

# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
LAUNCH
  chmod +x "${launcher}"
  log "INFO Wrote launcher ${launcher}"
}

main() {
  log "INFO Generating hybrid core engine (Java + Python + Rust)..."
  ensure_deps
  generate_layout
  compile_java
  check_python
  build_rust
  write_launcher
  log "INFO Core engine bundle generated."
  echo "GOT UM."
}

main "$@"

# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
