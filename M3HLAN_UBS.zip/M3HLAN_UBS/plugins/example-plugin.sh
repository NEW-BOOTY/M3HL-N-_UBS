#!/usr/bin/env bash
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
set -euo pipefail

read -r payload || payload="{}"
echo "[PLUGIN] Example plugin payload: ${payload}" >&2

cat <<EOF
{
  "status": "ok",
  "plugin": "example",
  "timestamp": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
}
EOF

# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */

