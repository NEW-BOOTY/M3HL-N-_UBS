#!/usr/bin/env bash
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "[TEST] Running M3hl@n! Smoke Test..."
bash "${ROOT_DIR}/M3HLAN_UBS_MASTER.sh"
./bin/m3hlan-build build
echo "[TEST] Integration test completed successfully."

# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */

