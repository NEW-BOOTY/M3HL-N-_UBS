/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

public final class Hello {
    public static void main(String[] args) {
        System.out.println("Hello from the M3hl@n! Java Example Project");
    }
}

/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

