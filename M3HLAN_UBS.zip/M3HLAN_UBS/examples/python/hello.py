# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */

def main() -> None:
    print("Hello from the M3hl@n! Python Example Project")

if __name__ == '__main__':
    main()

# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */

