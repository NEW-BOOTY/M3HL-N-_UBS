#!/usr/bin/env bash
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
set -euo pipefail
ROOT_DIR="${1:-.}"
if [[ -f "${ROOT_DIR}/Cargo.toml" ]]; then
  (cd "${ROOT_DIR}" && cargo build)
else
  echo "[ADAPTER-RUST] No Cargo.toml at ${ROOT_DIR}" >&2
fi
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

