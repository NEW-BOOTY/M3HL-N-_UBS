#!/usr/bin/env bash
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
set -euo pipefail
ROOT_DIR="${1:-.}"
if command -v poetry >/dev/null 2>&1; then
  (cd "${ROOT_DIR}" && poetry install && poetry build)
else
  echo "[ADAPTER-PYTHON] Poetry not installed" >&2
fi
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

