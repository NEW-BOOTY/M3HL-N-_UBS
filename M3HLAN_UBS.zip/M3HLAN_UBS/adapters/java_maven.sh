#!/usr/bin/env bash
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
set -euo pipefail
ROOT_DIR="${1:-.}"
if [[ -f "${ROOT_DIR}/pom.xml" ]]; then
  mvn -q -f "${ROOT_DIR}/pom.xml" -DskipTests package
else
  echo "[ADAPTER-JAVA] No pom.xml at ${ROOT_DIR}" >&2
fi
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

