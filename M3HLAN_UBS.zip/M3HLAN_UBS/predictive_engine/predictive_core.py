#!/usr/bin/env python3
"""
Copyright © 2025 Devin B. Royal.
All Rights Reserved.
"""

import pathlib
import re
import sys
from collections import Counter
from datetime import datetime


PROJECT_ROOT = pathlib.Path(__file__).resolve().parents[1]
LOG_MASTER = PROJECT_ROOT / "logs" / "M3HLAN_UBS_MASTER.log"
LOG_BUILD = PROJECT_ROOT / "logs" / "m3hlan-build.log"
STATE_DIR = PROJECT_ROOT / "predictive_engine" / "state"
ADVICE_FILE = STATE_DIR / "advice_nodes.txt"
INSIGHTS_FILE = PROJECT_ROOT / "docs" / "insights_dashboard.md"


def read_lines(path: pathlib.Path) -> list[str]:
    if not path.is_file():
        return []
    try:
        return path.read_text(encoding="utf-8", errors="ignore").splitlines()
    except OSError:
        return []


def find_hot_nodes(lines: list[str], threshold: int = 3) -> list[str]:
    """
    Looks for patterns like:
    [INFO] Executing node: python-core
    [INFO] Executing node: rust-cas
    """
    node_re = re.compile(r"Executing node:\s+([A-Za-z0-9_\-]+)")
    counter: Counter[str] = Counter()
    for line in lines:
        m = node_re.search(line)
        if m:
            counter[m.group(1)] += 1
    return [n for n, c in counter.items() if c >= threshold]


def main(argv: list[str]) -> int:
    STATE_DIR.mkdir(parents=True, exist_ok=True)

    master_lines = read_lines(LOG_MASTER)
    build_lines = read_lines(LOG_BUILD)
    combined = master_lines + build_lines

    hot_nodes = find_hot_nodes(combined, threshold=3)
    recommended_concurrency = 1
    if len(hot_nodes) >= 2:
        recommended_concurrency = 2
    if len(hot_nodes) >= 4:
        recommended_concurrency = 4

    # Write advice file consumed by Java engine
    with ADVICE_FILE.open("w", encoding="utf-8") as f:
        f.write(f"concurrency={recommended_concurrency}\n")
        for node in hot_nodes:
            f.write(f"{node}\n")

    # Update insights dashboard with a quick summary footer
    timestamp = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    summary = [
        "",
        "## Predictive Build Summary (auto-generated)",
        f"- Last updated: {timestamp}",
        f"- Hot nodes detected: {', '.join(hot_nodes) if hot_nodes else 'none'}",
        f"- Recommended concurrency: {recommended_concurrency}",
    ]

    try:
        base = INSIGHTS_FILE.read_text(encoding="utf-8")
    except OSError:
        base = "/*\n * Copyright © 2025 Devin B. Royal.\n * All Rights Reserved.\n */\n\n# M3hl@n! Predictive Build Intelligence — Insights Dashboard\n"

    new_content = base.split("\n## Predictive Build Summary", 1)[0].rstrip()
    new_content += "\n" + "\n".join(summary) + "\n"
    INSIGHTS_FILE.write_text(new_content, encoding="utf-8")

    print("[PREDICT] Updated advice_nodes.txt and insights_dashboard.md")
    print("GOT UM.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

"""
Copyright © 2025 Devin B. Royal.
All Rights Reserved.
"""
