/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

# M3hl@n! Error Catalog

- M3H-0001: DAG_INCOMPLETE
- M3H-0002: CAS_WRITE_FAILED
- M3H-0003: SANDBOX_DENIED
- M3H-0004: ADAPTER_FAILURE
- M3H-0005: PLUGIN_PROTOCOL_ERROR

Each error defines:
- Root cause
- Remediation
- Retry policy

/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

