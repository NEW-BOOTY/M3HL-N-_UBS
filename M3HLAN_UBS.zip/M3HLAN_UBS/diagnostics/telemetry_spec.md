/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

# M3hl@n! Telemetry Specification

Metrics:
- m3h_build_duration_seconds
- m3h_build_success_total
- m3h_build_failure_total
- m3h_cache_hit_ratio

Traces:
- Spans per DAG node
- Spans per adapter invocation

Events:
- Policy gate outcomes
- Plugin failure / success

/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

