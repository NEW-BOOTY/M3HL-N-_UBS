#!/usr/bin/env bash
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
set -euo pipefail
LOG_FILE="${1:-logs/M3HLAN_UBS_MASTER.log}"
if [[ ! -f "${LOG_FILE}" ]]; then
  echo "[AI-DIAG] Log file not found: ${LOG_FILE}" >&2
  exit 1
fi
echo "[AI-DIAG] Showing last 80 warnings/errors..."
grep -E "ERROR|WARN" "${LOG_FILE}" | tail -80 || true
echo "[AI-DIAG] Common causes: missing toolchains, denied sandbox permissions, adapter failures."
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */

