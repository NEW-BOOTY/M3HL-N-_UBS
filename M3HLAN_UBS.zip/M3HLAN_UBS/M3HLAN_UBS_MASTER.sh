#!/usr/bin/env bash
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG="${ROOT}/logs/M3HLAN_UBS_MASTER.log"
mkdir -p "${ROOT}/logs"

log() {
  local level="$1"; shift
  local msg="$*"
  local ts
  ts="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
  echo "[${ts}] [MASTER] [${level}] ${msg}" | tee -a "${LOG}"
}

run_bundle() {
  local name="$1"
  local script="$2"
  if [[ ! -x "${script}" ]]; then
    log "WARN" "Bundle script ${script} missing or not executable; skipping."
    return 0
  fi
  log "INFO" "Starting bundle ${name} (${script})"
  if bash "${script}"; then
    log "INFO" "Bundle ${name} completed successfully."
  else
    log "ERROR" "Bundle ${name} failed."
    echo "TRY AGAIN."
    exit 1
  fi
}

main() {
  log "INFO" "Clean master build starting..."

  run_bundle "core_engine_bundle"        "${ROOT}/scripts/bundle_core_engine.sh"
  run_bundle "manifest_adapter_bundle"   "${ROOT}/scripts/bundle_manifest_adapter.sh"
  run_bundle "observability_bundle"      "${ROOT}/scripts/bundle_observability.sh"
  run_bundle "dev_ergonomics_bundle"     "${ROOT}/scripts/bundle_dev_ergonomics.sh"
  run_bundle "extension_ecosystem_bundle" "${ROOT}/scripts/bundle_extension_ecosystem.sh"

  log "INFO" "All bundles completed."
  echo "GOT UM."
}

main "$@"

# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
