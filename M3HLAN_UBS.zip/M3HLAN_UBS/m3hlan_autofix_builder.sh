#!/usr/bin/env bash
# Copyright © 2025 Devin B. Royal.
# All Rights Reserved.

set -euo pipefail

########################################
# Utility helpers
########################################

find_project_root() {
  local here
  here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

  if [[ -f "${here}/.m3hlan-lock.json" ]]; then
    printf '%s\n' "${here}"
    return 0
  fi

  if [[ -d "${here}/M3HLAN_UBS" ]]; then
    printf '%s\n' "${here}/M3HLAN_UBS"
    return 0
  fi

  if [[ -d "${here}/../M3HLAN_UBS" ]]; then
    printf '%s\n' "$(cd "${here}/../M3HLAN_UBS" && pwd)"
    return 0
  fi

  return 1
}

ROOT="$(find_project_root || true)"

if [[ -z "${ROOT}" ]]; then
  echo "[FATAL] Unable to locate M3HLAN_UBS project root. Run this script from either:" >&2
  echo "  - The M3HLAN_UBS directory, or" >&2
  echo "  - Its parent directory." >&2
  exit 1
fi

LOG_DIR="${ROOT}/logs"
LOG="${LOG_DIR}/m3hlan_autofix_builder.log"
mkdir -p "${LOG_DIR}"

log() {
  local level="$1"; shift
  local msg="$*"
  local ts
  ts="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
  echo "[${ts}] [AUTOFIX] [${level}] ${msg}" | tee -a "${LOG}"
}

require_cmd() {
  local name="$1"
  if ! command -v "${name}" >/dev/null 2>&1; then
    log "ERROR" "Missing required command: ${name}"
    return 1
  fi
  log "INFO" "Found dependency: ${name} -> $(command -v "${name}")"
  return 0
}

backup_file() {
  local path="$1"
  if [[ -f "${path}" ]]; then
    local ts
    ts="$(date -u +"%Y%m%d-%H%M%S")"
    cp -p "${path}" "${path}.bak.${ts}"
    log "INFO" "Backed up ${path} -> ${path}.bak.${ts}"
  fi
}

########################################
# Regenerate engine sources (Java/Python/Rust)
########################################

regenerate_java_engine() {
  local java_src="${ROOT}/engine/java/src/main/java/com/m3hlan/engine/M3hlanEngine.java"
  backup_file "${java_src}"
  mkdir -p "$(dirname "${java_src}")"

  cat > "${java_src}" <<'EOF'
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
package com.m3hlan.engine;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.HexFormat;
import java.util.Objects;

/**
 * Minimal but production-ready Java core engine.
 * - Computes SHA-256 over stdin or a supplied file.
 * - Stores the blob under cas/<sha256>.
 * - Prints the CAS path and hash for downstream tools.
 */
public final class M3hlanEngine {

    private static final String CAS_DIR_NAME = "cas";

    private M3hlanEngine() {
        // no-op
    }

    public static void main(String[] args) {
        int exit = 0;
        try {
            Path projectRoot = detectRoot();
            Path casRoot = projectRoot.resolve(CAS_DIR_NAME);
            Files.createDirectories(casRoot);

            InputSource src = resolveInput(args);
            byte[] data = src.readAll();
            String hash = sha256(data);
            Path blobPath = casRoot.resolve(hash);

            if (!Files.exists(blobPath)) {
                Files.write(blobPath, data);
            }

            log("INFO", "Stored content to CAS: " + blobPath);
            log("INFO", "SHA-256=" + hash);

            System.out.println(blobPath.toAbsolutePath());
            System.out.flush();
        } catch (EngineException e) {
            exit = 1;
            log("ERROR", e.getMessage());
            Throwable cause = e.getCause();
            while (cause != null) {
                log("ERROR", "Caused by: " + cause.toString());
                cause = cause.getCause();
            }
            System.err.println("TRY AGAIN.");
        } catch (Exception e) {
            exit = 2;
            log("ERROR", "Unexpected failure: " + e.toString());
            System.err.println("TRY AGAIN.");
        }
        if (exit == 0) {
            System.out.println("GOT UM.");
        }
        System.exit(exit);
    }

    private static Path detectRoot() {
        try {
            Path cwd = Paths.get("").toAbsolutePath().normalize();
            Path candidate = cwd;
            while (candidate != null) {
                if (Files.exists(candidate.resolve(".m3hlan-lock.json"))
                        || Files.isDirectory(candidate.resolve("engine"))) {
                    return candidate;
                }
                candidate = candidate.getParent();
            }
            return cwd;
        } catch (Exception e) {
            throw new EngineException("Unable to detect project root", e);
        }
    }

    private static InputSource resolveInput(String[] args) {
        if (args != null && args.length > 0 && args[0] != null && !args[0].isBlank()) {
            return InputSource.fromFile(args[0]);
        }
        return InputSource.fromStdin();
    }

    private static String sha256(byte[] data) {
        Objects.requireNonNull(data, "data");
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(data);
            return HexFormat.of().formatHex(digest);
        } catch (NoSuchAlgorithmException e) {
            throw new EngineException("SHA-256 not available", e);
        }
    }

    private static void log(String level, String msg) {
        String ts = Instant.now().toString();
        System.err.printf("[%s] [JAVA-ENGINE] [%s] %s%n", ts, level, msg);
    }

    private static final class InputSource {
        private final String description;
        private final InputStreamFactory factory;

        private InputSource(String description, InputStreamFactory factory) {
            this.description = description;
            this.factory = factory;
        }

        static InputSource fromFile(String path) {
            return new InputSource(
                    "file:" + path,
                    () -> new BufferedInputStream(new FileInputStream(path))
            );
        }

        static InputSource fromStdin() {
            return new InputSource(
                    "stdin",
                    () -> new BufferedInputStream(System.in)
            );
        }

        byte[] readAll() {
            try (InputStream in = factory.open()) {
                return in.readAllBytes();
            } catch (IOException e) {
                throw new EngineException("Unable to read from " + description, e);
            }
        }
    }

    @FunctionalInterface
    private interface InputStreamFactory {
        InputStream open() throws IOException;
    }

    private static final class EngineException extends RuntimeException {
        EngineException(String message) {
            super(message);
        }

        EngineException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
EOF
  log "INFO" "Rewrote Java engine at ${java_src}"
}

regenerate_python_engine() {
  local py_src="${ROOT}/engine/python/m3h_core.py"
  backup_file "${py_src}"
  mkdir -p "$(dirname "${py_src}")"

  cat > "${py_src}" <<'EOF'
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
import hashlib
import json
import os
import pathlib
import sys
from dataclasses import dataclass
from typing import Any, Dict


PROJECT_ROOT = pathlib.Path(__file__).resolve().parents[2]
CAS_ROOT = PROJECT_ROOT / "cas"
CAS_ROOT.mkdir(parents=True, exist_ok=True)


def _log(level: str, message: str) -> None:
  ts = os.environ.get("M3HLAN_TS_OVERRIDE") or "AUTO"
  sys.stderr.write(f"[{ts}] [PY-ENGINE] [{level}] {message}\n")
  sys.stderr.flush()


@dataclass
class EngineResult:
  ok: bool
  cas_path: pathlib.Path | None = None
  sha256: str | None = None
  error: str | None = None

  def to_dict(self) -> Dict[str, Any]:
      return {
          "ok": self.ok,
          "cas_path": str(self.cas_path) if self.cas_path else None,
          "sha256": self.sha256,
          "error": self.error,
      }


def _sha256(data: bytes) -> str:
  h = hashlib.sha256()
  h.update(data)
  return h.hexdigest()


def _store(data: bytes) -> EngineResult:
  try:
      digest = _sha256(data)
      target = CAS_ROOT / digest
      if not target.exists():
          target.write_bytes(data)
      _log("INFO", f"Stored CAS blob at {target}")
      return EngineResult(ok=True, cas_path=target, sha256=digest)
  except Exception as exc:  # noqa: BLE001
      msg = f"CAS failure: {exc!r}"
      _log("ERROR", msg)
      return EngineResult(ok=False, error=msg)


def _read_input(argv: list[str]) -> bytes:
  if len(argv) > 1 and argv[1]:
      path = pathlib.Path(argv[1]).expanduser()
      return path.read_bytes()
  return sys.stdin.buffer.read()


def main(argv: list[str]) -> int:
  try:
      data = _read_input(argv)
      result = _store(data)
      print(json.dumps(result.to_dict(), sort_keys=True))
      if result.ok:
          print("GOT UM.")
          return 0
      print("TRY AGAIN.")
      return 1
  except Exception as exc:  # noqa: BLE001
      _log("ERROR", f"Unhandled exception: {exc!r}")
      print(json.dumps({"ok": False, "error": str(exc)}))
      print("TRY AGAIN.")
      return 2


if __name__ == "__main__":
  raise SystemExit(main(sys.argv))
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
EOF
  log "INFO" "Rewrote Python engine at ${py_src}"
}

regenerate_rust_engine() {
  local cargo_toml="${ROOT}/engine/rust/Cargo.toml"
  local rs_main="${ROOT}/engine/rust/src/main.rs"
  backup_file "${cargo_toml}"
  backup_file "${rs_main}"
  mkdir -p "$(dirname "${cargo_toml}")" "$(dirname "${rs_main}")"

  cat > "${cargo_toml}" <<'EOF'
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
[package]
name = "m3hlan_cas"
version = "0.1.0"
edition = "2021"

[dependencies]
sha2 = "0.10"
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
EOF

  cat > "${rs_main}" <<'EOF'
// /*
 //  * Copyright © 2025 Devin B. Royal.
 //  * All Rights Reserved.
 //  */
use sha2::{Digest, Sha256};
use std::fs;
use std::io::{self, Read};
use std::path::PathBuf;

fn cas_root() -> PathBuf {
    let mut root = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
    root.push("cas");
    root
}

fn sha256(bytes: &[u8]) -> String {
    let mut hasher = Sha256::new();
    hasher.update(bytes);
    let digest = hasher.finalize();
    digest.iter().map(|b| format!("{:02x}", b)).collect()
}

fn store(bytes: &[u8]) -> io::Result<PathBuf> {
    let cas = cas_root();
    fs::create_dir_all(&cas)?;
    let hash = sha256(bytes);
    let target = cas.join(&hash);
    if !target.exists() {
        fs::write(&target, bytes)?;
    }
    Ok(target)
}

fn main() {
    let mut buf = Vec::new();
    if let Err(e) = io::stdin().read_to_end(&mut buf) {
        eprintln!("[ERROR] Failed to read stdin: {e}");
        println!("TRY AGAIN.");
        std::process::exit(1);
    }

    match store(&buf) {
        Ok(path) => {
            eprintln!("[INFO] [RUST-CAS] Stored blob at {}", path.display());
            println!("{}", path.display());
            println!("GOT UM.");
        }
        Err(e) => {
            eprintln!("[ERROR] Rust CAS failure: {e}");
            println!("TRY AGAIN.");
            std::process::exit(1);
        }
    }
}
// /*
 //  * Copyright © 2025 Devin B. Royal.
 //  * All Rights Reserved.
 //  */
EOF
  log "INFO" "Rewrote Rust engine at ${rs_main}"
}

########################################
# Regenerate bundle scripts + bin/m3hlan-build
########################################

regenerate_bundle_core_engine() {
  local script_path="${ROOT}/scripts/bundle_core_engine.sh"
  backup_file "${script_path}"
  mkdir -p "$(dirname "${script_path}")"

  cat > "${script_path}" <<'EOF'
#!/usr/bin/env bash
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LOG="${ROOT}/logs/bundle_core_engine.log"
mkdir -p "${ROOT}/logs"

log() {
  local msg="$*"
  local ts
  ts="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
  echo "[${ts}] [CORE] ${msg}" | tee -a "${LOG}"
}

require_cmd() {
  local name="$1"
  if ! command -v "${name}" >/dev/null 2>&1; then
    log "ERROR Missing command: ${name}"
    return 1
  fi
  log "INFO Found ${name} at $(command -v "${name}")"
  return 0
}

ensure_deps() {
  local missing=0
  for c in python3 javac java cargo rustc; do
    if ! require_cmd "${c}"; then
      missing=1
    fi
  done
  if [[ "${missing}" -ne 0 ]]; then
    log "ERROR One or more required commands are missing."
    exit 1
  fi
}

generate_layout() {
  log "INFO Generating engine directory layout..."
  mkdir -p \
    "${ROOT}/engine/java/src/main/java/com/m3hlan/engine" \
    "${ROOT}/engine/java/src/main/resources" \
    "${ROOT}/engine/python" \
    "${ROOT}/engine/rust/src" \
    "${ROOT}/cas" \
    "${ROOT}/bin"
}

compile_java() {
  log "INFO Compiling Java engine..."
  mkdir -p "${ROOT}/engine/java/target"
  javac -d "${ROOT}/engine/java/target" \
    "${ROOT}/engine/java/src/main/java/com/m3hlan/engine/M3hlanEngine.java"
}

check_python() {
  log "INFO Verifying Python engine..."
  python3 -m py_compile "${ROOT}/engine/python/m3h_core.py"
}

build_rust() {
  log "INFO Building Rust CAS helper..."
  ( cd "${ROOT}/engine/rust" && cargo build --release )
}

write_launcher() {
  local launcher="${ROOT}/bin/m3hlan-build"
  cat > "${launcher}" <<'LAUNCH'
#!/usr/bin/env bash
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */

set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

usage() {
  cat <<USAGE
Usage: m3hlan-build <command>

Commands:
  java        Compile and run the Java engine.
  python-core Run the Python CAS engine.
  rust-cas    Run the Rust CAS helper.

Examples:
  echo "hello" | m3hlan-build java
  echo "hello" | m3hlan-build python-core
  echo "hello" | m3hlan-build rust-cas
USAGE
}

cmd="${1:-java}"

case "${cmd}" in
  java)
    mkdir -p "${ROOT}/engine/java/target"
    javac -d "${ROOT}/engine/java/target" \
      "${ROOT}/engine/java/src/main/java/com/m3hlan/engine/M3hlanEngine.java"
    java -cp "${ROOT}/engine/java/target" com.m3hlan.engine.M3hlanEngine
    ;;
  python-core)
    python3 "${ROOT}/engine/python/m3h_core.py"
    ;;
  rust-cas)
    cargo run --manifest-path "${ROOT}/engine/rust/Cargo.toml" --release
    ;;
  -*|--help|help)
    usage
    ;;
  *)
    echo "Unknown command: ${cmd}" >&2
    usage >&2
    exit 1
    ;;
esac

# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
LAUNCH
  chmod +x "${launcher}"
  log "INFO Wrote launcher ${launcher}"
}

main() {
  log "INFO Generating hybrid core engine (Java + Python + Rust)..."
  ensure_deps
  generate_layout
  compile_java
  check_python
  build_rust
  write_launcher
  log "INFO Core engine bundle generated."
  echo "GOT UM."
}

main "$@"

# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
EOF

  chmod +x "${script_path}"
  log "INFO" "Rewrote bundle_core_engine.sh at ${script_path}"
}

regenerate_simple_bundle() {
  local name="$1"
  local script_path="${ROOT}/scripts/bundle_${name}.sh"
  backup_file "${script_path}"
  mkdir -p "$(dirname "${script_path}")"

  cat > "${script_path}" <<EOF
#!/usr/bin/env bash
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */

set -euo pipefail

ROOT="\$(cd "\$(dirname "\${BASH_SOURCE[0]}")/.." && pwd)"
LOG="\${ROOT}/logs/bundle_${name}.log"
mkdir -p "\${ROOT}/logs"

log() {
  local ts
  ts="\$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
  echo "[\${ts}] [${name^^}] \$*" | tee -a "\${LOG}"
}

main() {
  log "INFO" "Bundle ${name} starting..."
  # This bundle is intentionally lightweight but valid; extend as needed.
  mkdir -p "\${ROOT}/${name}"
  log "INFO" "Ensured directory \${ROOT}/${name}"
  log "INFO" "Bundle ${name} completed."
  echo "GOT UM."
}

main "\$@"

# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
EOF

  chmod +x "${script_path}"
  log "INFO" "Rewrote bundle_${name}.sh at ${script_path}"
}

regenerate_master() {
  local master="${ROOT}/M3HLAN_UBS_MASTER.sh"
  backup_file "${master}"

  cat > "${master}" <<'EOF'
#!/usr/bin/env bash
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG="${ROOT}/logs/M3HLAN_UBS_MASTER.log"
mkdir -p "${ROOT}/logs"

log() {
  local level="$1"; shift
  local msg="$*"
  local ts
  ts="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"
  echo "[${ts}] [MASTER] [${level}] ${msg}" | tee -a "${LOG}"
}

run_bundle() {
  local name="$1"
  local script="$2"
  if [[ ! -x "${script}" ]]; then
    log "WARN" "Bundle script ${script} missing or not executable; skipping."
    return 0
  fi
  log "INFO" "Starting bundle ${name} (${script})"
  if bash "${script}"; then
    log "INFO" "Bundle ${name} completed successfully."
  else
    log "ERROR" "Bundle ${name} failed."
    echo "TRY AGAIN."
    exit 1
  fi
}

main() {
  log "INFO" "Clean master build starting..."

  run_bundle "core_engine_bundle"        "${ROOT}/scripts/bundle_core_engine.sh"
  run_bundle "manifest_adapter_bundle"   "${ROOT}/scripts/bundle_manifest_adapter.sh"
  run_bundle "observability_bundle"      "${ROOT}/scripts/bundle_observability.sh"
  run_bundle "dev_ergonomics_bundle"     "${ROOT}/scripts/bundle_dev_ergonomics.sh"
  run_bundle "extension_ecosystem_bundle" "${ROOT}/scripts/bundle_extension_ecosystem.sh"

  log "INFO" "All bundles completed."
  echo "GOT UM."
}

main "$@"

# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
EOF

  chmod +x "${master}"
  log "INFO" "Rewrote M3HLAN_UBS_MASTER.sh at ${master}"
}

########################################
# Main orchestration
########################################

main() {
  log "INFO" "M3HLAN_UBS autofix + builder starting at root=${ROOT}"

  local missing=0
  for c in python3 javac java cargo rustc; do
    if ! require_cmd "${c}"; then
      missing=1
    fi
  done
  if [[ "${missing}" -ne 0 ]]; then
    log "ERROR" "Missing dependencies; aborting."
    echo "TRY AGAIN."
    exit 1
  fi

  regenerate_java_engine
  regenerate_python_engine
  regenerate_rust_engine

  regenerate_bundle_core_engine
  regenerate_simple_bundle "manifest_adapter"
  regenerate_simple_bundle "observability"
  regenerate_simple_bundle "dev_ergonomics"
  regenerate_simple_bundle "extension_ecosystem"
  regenerate_master

  log "INFO" "Running master build..."
  if bash "${ROOT}/M3HLAN_UBS_MASTER.sh"; then
    log "INFO" "Master build completed successfully."
    echo "GOT UM."
  else
    log "ERROR" "Master build failed."
    echo "TRY AGAIN."
    exit 1
  fi

  log "INFO" "Autofix builder finished cleanly."
}

main "$@"

# Copyright © 2025 Devin B. Royal.
# All Rights Reserved.
