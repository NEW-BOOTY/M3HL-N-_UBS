# /*
# * Copyright © 2025 Devin B. Royal.
# * All Rights Reserved.
# */

# SPDX-License-Identifier: LicenseRef-M3hlan-Enterprise

# QUICKSTART

1. ./build.sh init
2. ./build.sh resolve
3. make build
4. make test
5. make sbom sign attest
6. make release

Validate hashes match across platforms.

# /*
# * Copyright © 2025 Devin B. Royal.
# * All Rights Reserved.
# */