#!/bin/bash
#
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
#
# SPDX-License-Identifier: LicenseRef-M3hlan-Enterprise

echo "Running end-to-end test..."
./build.sh build
echo "Test passed."

# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */