# /*
# * Copyright © 2025 Devin B. Royal.
# * All Rights Reserved.
# */

# SPDX-License-Identifier: LicenseRef-M3hlan-Enterprise

# Content-Addressed Storage (CAS) Spec

## Overview
- Stores build artifacts, inputs, and environments by content hash (SHA-256).
- Ensures determinism: Identical inputs yield identical hashes and outputs.

## Key Features
- Action-level inputs: Files, env vars, toolchains fingerprinted.
- Environment fingerprints: OS, arch, vars hashed into key.
- Toolchain pinning: Versions locked in .m3hlan-lock.json.
- Storage: Local dir (.m3hlan-cache) or remote (gRPC backend).

## Usage
- Hash computation: Canonical sort + SHA-256.
- Retrieval: Check hash existence before execution.

# /*
# * Copyright © 2025 Devin B. Royal.
# * All Rights Reserved.
# */