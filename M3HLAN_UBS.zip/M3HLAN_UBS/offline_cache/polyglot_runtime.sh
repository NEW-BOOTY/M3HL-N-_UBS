#!/bin/bash
# [Full script from above pasted here — already delivered]
