<!-- LICENSE.md -->
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */

# M3hl@n! Enterprise License
# SPDX-License-Identifier: LicenseRef-M3hlan-Enterprise
# Version: 1.0 | Effective Date: 2025

## Preamble

The M3hl@n! Unified Build System constitutes original intellectual property created by Devin B. Royal. This license grants limited rights for enterprise evaluation, internal deployment, and derivative works under strict conditions.

## Grant of License

Subject to the terms below, Devin B. Royal grants a non-exclusive, non-transferable, revocable license to:

1. Use the software internally within a single legal entity.
2. Modify the software for internal purposes only.
3. Deploy in production environments owned or controlled by the licensee.

## Restrictions (Non-Negotiable)

- NO redistribution in source or binary form without explicit written consent.
- NO public disclosure, publication, or contribution to open-source repositories.
- NO removal or alteration of copyright headers, branding ("GOT UM." / "TRY AGAIN."), or provenance metadata.
- NO use in competing build-system products or services.
- NO reverse engineering beyond what is required for interoperability with licensee’s own systems.

## Ownership

All right, title, and interest in the software, including all derivatives, remains exclusively with Devin B. Royal. Licensee acquires no ownership rights.

## Termination

This license terminates automatically upon any breach. Upon termination, all copies must be destroyed.

## Governing Law

This license shall be governed by the laws of the United States and the State of Delaware, without regard to conflict of law principles.

## Contact & Enterprise Licensing

For commercial licensing, support contracts, or custom extensions contact:  
devin.royal@enterprise.m3hlan

Copyright © 2025 Devin B. Royal. All Rights Reserved.

# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */