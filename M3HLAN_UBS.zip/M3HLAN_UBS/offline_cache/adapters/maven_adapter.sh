#!/bin/bash
#
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
#
# SPDX-License-Identifier: LicenseRef-M3hlan-Enterprise

echo "Maven Adapter: Running mvn package"
mvn package || exit 1

# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */