#!/bin/bash
#
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
#
# SPDX-License-Identifier: LicenseRef-M3hlan-Enterprise

echo "NPM Adapter: Running npm install && npm build"
npm install && npm run build || exit 1

# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */