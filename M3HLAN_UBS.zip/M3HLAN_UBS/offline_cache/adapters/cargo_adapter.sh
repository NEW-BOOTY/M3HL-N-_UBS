#!/bin/bash
#
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
#
# SPDX-License-Identifier: LicenseRef-M3hlan-Enterprise

echo "Cargo Adapter: Running cargo build --release"
cargo build --release || exit 1

# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */