# /*
# * Copyright © 2025 Devin B. Royal.
# * All Rights Reserved.
# */

# SPDX-License-Identifier: LicenseRef-M3hlan-Enterprise

# Error Catalog

## E001: Cache Miss
- Cause: No matching hash.
- Recovery: Run task and cache.

## E002: Policy Violation
- Cause: License mismatch.
- Recovery: Update config.

## E003: Transient Network
- Cause: Timeout.
- Recovery: Auto-retry.

# /*
# * Copyright © 2025 Devin B. Royal.
# * All Rights Reserved.
# */