# /*
# * Copyright © 2025 Devin B. Royal.
# * All Rights Reserved.
# */

# SPDX-License-Identifier: LicenseRef-M3hlan-Enterprise

# Plugin API Spec

## Extension Points
- Adapters: Implement run_task function.
- Policies: Hook into pre-build checks.

## Interface
- JSON/gRPC for input/output.
- Example: plugin.sh --input json --output json

# /*
# * Copyright © 2025 Devin B. Royal.
# * All Rights Reserved.
# */