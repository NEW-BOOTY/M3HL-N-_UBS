examples/polyglot/README.md
# Polyglot Example Project
- Java API gateway
- Python ML inference
- Rust high-performance core
- Go distributed worker

Run: ./polyglot_runtime.sh build