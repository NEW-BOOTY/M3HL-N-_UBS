// /*
 //  * Copyright © 2025 Devin B. Royal.
 //  * All Rights Reserved.
 //  */
use sha2::{Digest, Sha256};
use std::fs;
use std::io::{self, Read};
use std::path::PathBuf;

fn cas_root() -> PathBuf {
    let mut root = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
    root.push("cas");
    root
}

fn sha256(bytes: &[u8]) -> String {
    let mut hasher = Sha256::new();
    hasher.update(bytes);
    let digest = hasher.finalize();
    digest.iter().map(|b| format!("{:02x}", b)).collect()
}

fn store(bytes: &[u8]) -> io::Result<PathBuf> {
    let cas = cas_root();
    fs::create_dir_all(&cas)?;
    let hash = sha256(bytes);
    let target = cas.join(&hash);
    if !target.exists() {
        fs::write(&target, bytes)?;
    }
    Ok(target)
}

fn main() {
    let mut buf = Vec::new();
    if let Err(e) = io::stdin().read_to_end(&mut buf) {
        eprintln!("[ERROR] Failed to read stdin: {e}");
        println!("TRY AGAIN.");
        std::process::exit(1);
    }

    match store(&buf) {
        Ok(path) => {
            eprintln!("[INFO] [RUST-CAS] Stored blob at {}", path.display());
            println!("{}", path.display());
            println!("GOT UM.");
        }
        Err(e) => {
            eprintln!("[ERROR] Rust CAS failure: {e}");
            println!("TRY AGAIN.");
            std::process::exit(1);
        }
    }
}
// /*
 //  * Copyright © 2025 Devin B. Royal.
 //  * All Rights Reserved.
 //  */
