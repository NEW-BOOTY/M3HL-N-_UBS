/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
package com.m3hlan.engine;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.HexFormat;
import java.util.Objects;

/**
 * Minimal but production-ready Java core engine.
 * - Computes SHA-256 over stdin or a supplied file.
 * - Stores the blob under cas/<sha256>.
 * - Prints the CAS path and hash for downstream tools.
 */
public final class M3hlanEngine {

    private static final String CAS_DIR_NAME = "cas";

    private M3hlanEngine() {
        // no-op
    }

    public static void main(String[] args) {
        int exit = 0;
        try {
            Path projectRoot = detectRoot();
            Path casRoot = projectRoot.resolve(CAS_DIR_NAME);
            Files.createDirectories(casRoot);

            InputSource src = resolveInput(args);
            byte[] data = src.readAll();
            String hash = sha256(data);
            Path blobPath = casRoot.resolve(hash);

            if (!Files.exists(blobPath)) {
                Files.write(blobPath, data);
            }

            log("INFO", "Stored content to CAS: " + blobPath);
            log("INFO", "SHA-256=" + hash);

            System.out.println(blobPath.toAbsolutePath());
            System.out.flush();
        } catch (EngineException e) {
            exit = 1;
            log("ERROR", e.getMessage());
            Throwable cause = e.getCause();
            while (cause != null) {
                log("ERROR", "Caused by: " + cause.toString());
                cause = cause.getCause();
            }
            System.err.println("TRY AGAIN.");
        } catch (Exception e) {
            exit = 2;
            log("ERROR", "Unexpected failure: " + e.toString());
            System.err.println("TRY AGAIN.");
        }
        if (exit == 0) {
            System.out.println("GOT UM.");
        }
        System.exit(exit);
    }

    private static Path detectRoot() {
        try {
            Path cwd = Paths.get("").toAbsolutePath().normalize();
            Path candidate = cwd;
            while (candidate != null) {
                if (Files.exists(candidate.resolve(".m3hlan-lock.json"))
                        || Files.isDirectory(candidate.resolve("engine"))) {
                    return candidate;
                }
                candidate = candidate.getParent();
            }
            return cwd;
        } catch (Exception e) {
            throw new EngineException("Unable to detect project root", e);
        }
    }

    private static InputSource resolveInput(String[] args) {
        if (args != null && args.length > 0 && args[0] != null && !args[0].isBlank()) {
            return InputSource.fromFile(args[0]);
        }
        return InputSource.fromStdin();
    }

    private static String sha256(byte[] data) {
        Objects.requireNonNull(data, "data");
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(data);
            return HexFormat.of().formatHex(digest);
        } catch (NoSuchAlgorithmException e) {
            throw new EngineException("SHA-256 not available", e);
        }
    }

    private static void log(String level, String msg) {
        String ts = Instant.now().toString();
        System.err.printf("[%s] [JAVA-ENGINE] [%s] %s%n", ts, level, msg);
    }

    private static final class InputSource {
        private final String description;
        private final InputStreamFactory factory;

        private InputSource(String description, InputStreamFactory factory) {
            this.description = description;
            this.factory = factory;
        }

        static InputSource fromFile(String path) {
            return new InputSource(
                    "file:" + path,
                    () -> new BufferedInputStream(new FileInputStream(path))
            );
        }

        static InputSource fromStdin() {
            return new InputSource(
                    "stdin",
                    () -> new BufferedInputStream(System.in)
            );
        }

        byte[] readAll() {
            try (InputStream in = factory.open()) {
                return in.readAllBytes();
            } catch (IOException e) {
                throw new EngineException("Unable to read from " + description, e);
            }
        }
    }

    @FunctionalInterface
    private interface InputStreamFactory {
        InputStream open() throws IOException;
    }

    private static final class EngineException extends RuntimeException {
        EngineException(String message) {
            super(message);
        }

        EngineException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
