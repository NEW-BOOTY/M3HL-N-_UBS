# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
import hashlib
import json
import os
import pathlib
import sys
from dataclasses import dataclass
from typing import Any, Dict


PROJECT_ROOT = pathlib.Path(__file__).resolve().parents[2]
CAS_ROOT = PROJECT_ROOT / "cas"
CAS_ROOT.mkdir(parents=True, exist_ok=True)


def _log(level: str, message: str) -> None:
  ts = os.environ.get("M3HLAN_TS_OVERRIDE") or "AUTO"
  sys.stderr.write(f"[{ts}] [PY-ENGINE] [{level}] {message}\n")
  sys.stderr.flush()


@dataclass
class EngineResult:
  ok: bool
  cas_path: pathlib.Path | None = None
  sha256: str | None = None
  error: str | None = None

  def to_dict(self) -> Dict[str, Any]:
      return {
          "ok": self.ok,
          "cas_path": str(self.cas_path) if self.cas_path else None,
          "sha256": self.sha256,
          "error": self.error,
      }


def _sha256(data: bytes) -> str:
  h = hashlib.sha256()
  h.update(data)
  return h.hexdigest()


def _store(data: bytes) -> EngineResult:
  try:
      digest = _sha256(data)
      target = CAS_ROOT / digest
      if not target.exists():
          target.write_bytes(data)
      _log("INFO", f"Stored CAS blob at {target}")
      return EngineResult(ok=True, cas_path=target, sha256=digest)
  except Exception as exc:  # noqa: BLE001
      msg = f"CAS failure: {exc!r}"
      _log("ERROR", msg)
      return EngineResult(ok=False, error=msg)


def _read_input(argv: list[str]) -> bytes:
  if len(argv) > 1 and argv[1]:
      path = pathlib.Path(argv[1]).expanduser()
      return path.read_bytes()
  return sys.stdin.buffer.read()


def main(argv: list[str]) -> int:
  try:
      data = _read_input(argv)
      result = _store(data)
      print(json.dumps(result.to_dict(), sort_keys=True))
      if result.ok:
          print("GOT UM.")
          return 0
      print("TRY AGAIN.")
      return 1
  except Exception as exc:  # noqa: BLE001
      _log("ERROR", f"Unhandled exception: {exc!r}")
      print(json.dumps({"ok": False, "error": str(exc)}))
      print("TRY AGAIN.")
      return 2


if __name__ == "__main__":
  raise SystemExit(main(sys.argv))
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
